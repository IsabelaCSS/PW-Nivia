﻿namespace Projeto3ds.Models
{
    public class Categoria
    {
        public int categoriaID { get; set; }
        public string categoriaNome { get; set; }
        public string desc {  get; set; }
        public List <Lanche> Lanche { get; set; }
    }
}
