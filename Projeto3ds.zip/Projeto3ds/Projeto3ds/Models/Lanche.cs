﻿namespace Projeto3ds.Models
{
    public class Lanche
    {
        public string descCurta { get; set; }
        public string descDetalhe { get; set; }
        public bool emEstoque {  get; set; }
        public int lancheID { get; set; }
        public string Nome { get; set;}
        public decimal preco { get; set; }
        public string imagemUrl { get; set; }
        public string lanchePreferido { get; set; }
        public string imgMini { get; set; }
        public virtual Categoria categoriaID { get; set; }
        public virtual Categoria categoria {  get; set; }
    }
}
